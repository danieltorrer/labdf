<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['consumer_key']			= 'YOUR CONSUMER KEY';
$config['consumer_secret']		= 'YOUR CONSUMER SECRET';

// If producing RSS
$config['feed_title']			= '@joshmoody';
$config['feed_url']				= 'http://twitter.com/joshmoody';
$config['feed_description']		= 'Feeds from @joshmoody on Twitter';