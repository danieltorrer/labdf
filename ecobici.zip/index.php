<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Ecobici</title>
	<script src="vendors/js/jquery.js"></script>
	<script src="vendors/js/ractive.js"></script>
</head>
<body>
	<h1>Busqueda</h1>

	<div id='container'></div>
	<div id="datos"></div>
	<div id="listaTwits"></div>
	
	<script id='myTemplate' type='text/ractive'>
		<form action="#" >
			<select name="hola" id="hola">
				{{#estaciones}}
				<option value="{{id}}">{{principal}}</option>
				{{/estaciones}}
			</select>
			<div id="botonsito">Precioname</div>
		</form>
	</script>
	<script id="plantillaDatos" type="text/ractive">
		{{#itemElegido}}
		{{id}}
		<span id="latitud">{{latitud}}</span>
		<span id="longitud">{{longitud}}</span>
		{{/itemElegido}}
	</script>
	<script id="listaTPL" type="text/ractive">
		{{#estatus}}
			<p><strong>{{#user}}{{name}} - @{{screen_name}} {{/user}} dijo: </strong>{{text}}</p>
		{{/estatus}}
	</script>
	
	<script>
		$(document).ready(inicio);
		function inicio(){
			var x = $.getJSON("lugares.json");
			x.done(function(datos)
			{
				var ractive = new Ractive({
					el: 'container',
					template: '#myTemplate',
					data: {
						estaciones : datos
					}
				});
				$("#botonsito").on("click", function()
				{
					var itemSeleccionado = $("#hola").val();
					var ractive = new Ractive({
						el: "datos",
						template:"#plantillaDatos",
						data:{
							itemElegido : datos[itemSeleccionado-1]
						}
					});
					$("#plantillaDatos").trigger("change");
				});
				$("#plantillaDatos").on("change",function(){
					var pet_busqueda = "Ecobici";
					var pet_latitud = $("#latitud").text();
					var pet_longitud = $("#longitud").text();
					$.getJSON("peticionTwitter.php",{busqueda:pet_busqueda,latitud:pet_latitud,longitud:pet_longitud}).done(
						function(datos){
							var ractive = new Ractive({
								el: "listaTwits",
								template: "#listaTPL",
								data:{
									estatus : datos["statuses"]
								}
							});
							console.log(datos["statuses"]);
						});
				});
			});

			
		}
	</script>
</body>
</html>