<?php 
ini_set('display_errors', 1);
include("TwitterAPIExchange.php");
$settings = array(
    'oauth_access_token' => "93753732-biNDPqIdI10bYjL26AAZTf4BUpOo1JoWApXs7XJk2",
    'oauth_access_token_secret' => "rlyBFdSpMt6zWkAHbTTxjm0ldiEN6lWIrfffdOZt7Y4fT",
    'consumer_key' => "h51v6StKUWbdxdlfa6jqCg",
    'consumer_secret' => "XNksvb5nE6ECWEtblBUgLsA6DqRiraTfhYmMuFI3c"
);

$busqueda = $_GET["busqueda"];
$latitud = $_GET["latitud"];
$longitud = $_GET["longitud"];


$url = 'https://api.twitter.com/1.1/search/tweets.json';
$getfield = '?q='.$busqueda.'&geocode='.$latitud.','.$longitud.',1km&count=30';
$requestMethod = 'GET';

$twitter = new TwitterAPIExchange($settings);
echo $twitter->setGetfield($getfield)
             ->buildOauth($url, $requestMethod)
             ->performRequest();

 ?>